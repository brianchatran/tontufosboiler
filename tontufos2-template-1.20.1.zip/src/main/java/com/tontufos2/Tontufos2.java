// Paquete principal del mod
package com.tontufos2;



import com.tontufos2.blabber.HasFafaInInventoryCondition;
import com.tontufos2.blabber.HasTenEmeraldsInInventoryCondition;

import com.tontufos2.commands.PiramideTestCommand;
import com.tontufos2.entity.ModEntities;
import com.tontufos2.blocks.ModBlocks;
import com.tontufos2.items.ModItemGroups;
import com.tontufos2.items.ModItems;
import com.tontufos2.loot.AddItemLootModifier;
import com.tontufos2.sound.ModSounds;
import com.tontufos2.util.CharlySummonerHandler;
import com.tontufos2.util.ToxicityHandler;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.entity.damage.DamageType;
import net.minecraft.loot.condition.LootConditionType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.server.MinecraftServer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Clase principal del mod.
 */
public class Tontufos2 implements ModInitializer {
	public static final String MOD_ID = "tontufos2";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	private static MinecraftServer SERVER = null;

	@Override
	public void onInitialize() {
		// Registro de ítems, bloques y handlers
		ModItems.registerItems();
		ModItemGroups.registerItemGroups();
		ModBlocks.registerBlocks();
		ToxicityHandler.registerTickHandler();
		ModEntities.registerModEntities();
		CharlySummonerHandler.registerStructureCheck();
		PiramideTestCommand.register();
		ModSounds.registerSounds();
		com.tontufos2.loot.AddChestLootModifier.register();
		com.tontufos2.loot.AddMobLootModifier.register();
		com.tontufos2.loot.AddItemLootModifier.register();
		HasFafaInInventoryCondition.register();
		HasTenEmeraldsInInventoryCondition.register();

		// Registro del DamageType fafa_overdose correctamente en 1.20.1


		// Eventos para gestionar SERVER instance
		ServerLifecycleEvents.SERVER_STARTING.register(server -> SERVER = server);
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> SERVER = null);

		LOGGER.info("Hello Fabric world!");
	}


}
